'use strict';
 export class Links { 
constructor(){
this.obj={} 
 this.windows =  
 {} 
  
this.Items = { 
 };} 
 } 
 