'use strict';
 export class GlobalParameters {
 static get globals(){ 
 return {
  "ProjectName": "project",
  "MainIP": "127.0.0.1",
  "WebPort": 8043,
  "Language": "ru",
  "UpdateInterval": 100,
  "RequestServerPrefix": "",
  "RedundancyIP": null,
  "OfflineMode": false,
  "LogLevel": 3,
  "ControlCAD": false,
  "SaveEncodingCsv": "utf-8",
  "SaveStatePlace": "В HMI клиенте",
  "FlashInterval": 1000,
  "BlockDisabledControls": true,
  "DisabledControlsTooltip": null,
  "EnableNoPermissionInformationWindow": true,
  "RequestPasswordOnLogout": false,
  "DisplayItemNamesInMessages": true,
  "DisableOSAccessWhileLogin": false,
  "ManuallyEnteringLogin": false,
  "TrendRenderingType": "svg",
  "NormalizeGeometry": true,
  "BimServers": "null",
  "ScreensOptions": "{\"58140\":{\"Index\":0,\"DisableScale\":true,\"DialogFontName\":\"Arial\",\"DialogFontSize\":12,\"DialogHeaderSize\":20,\"ToolTipSettings\":{},\"ScreenCheckingOptions\":{\"ScreenChecking\":0,\"ScreenWidth\":1920,\"ScreenHeight\":1080,\"CheckScreenOrientation\":false,\"ScreenOrientation\":0,\"CheckTouchScreen\":false}}}",
  "DefaultScreenId": 58140,
  "BrowserLog": true,
  "Options": null,
  "UserColors": {}
}; }
}