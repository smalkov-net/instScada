export class Type {
    constructor() {
        this.type = {}}
}