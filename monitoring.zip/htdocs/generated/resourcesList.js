'use strict';
 export class ResourcesList {
 static get resourcesList(){ 
 return {}; }
}