'use strict';
export class WinDefs {
static get startWindow() {
    return {"58140":"58012"};
} 
static get mainFrame() { 
    return {"58140":"58153"};
}
constructor(){
this.obj={}
 
this.winDef={
'58012':{
'id':'58012',
'template':'t_58012',
'typeid':'58012',
'elname':'Window 1',
'objectid':'58003',
'z':"0",
'width':"1920",
'height':"1080",
'bordercolor':"rgb(128,128,128)",
'hideifdenycontrol':"false",
'tabindex':"0",
'mousecursorkind':"0",
},
'58140':{
'id':'58140',
'template':'t_58140',
'typeid':'58140',
'elname':'Screen template 1',
'objectid':'58138',
'width':"1920",
'height':"1080",
'bordercolor':"rgb(128,128,128)",
},

}
this.winMap={
  "58003": {
    "Window 1": "58012"
  },
  "58138": {
    "Screen template 1": "58140"
  }
}
}
}