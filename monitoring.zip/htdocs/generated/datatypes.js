'use strict';
 export class DataTypes { 
 static get dataTypes() { 
 return {
  "BOOL": {
    "DataType": "ElementaryType"
  },
  "BYTE": {
    "DataType": "ElementaryType"
  },
  "DINT": {
    "DataType": "ElementaryType"
  },
  "HMI.BorderStyleType": {
    "Values": [
      "Solid",
      "Dash",
      "Dot",
      "None"
    ],
    "DisplayValues": [
      "Solid",
      "Dash",
      "Dot",
      "None"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.GradientColorType": {
    "DataType": "ElementaryType"
  },
  "HMI.HorizontalAlignType": {
    "Values": [
      "Left",
      "Center",
      "Right"
    ],
    "DisplayValues": [
      "Left",
      "Center",
      "Right"
    ],
    "Indexes": [
      0,
      1,
      2
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.MouseCursorKinds": {
    "Values": [
      "Standard",
      "Pointer",
      "Crosshair",
      "Text",
      "NotAllowed",
      "Wait",
      "Help",
      "Move"
    ],
    "DisplayValues": [
      "Standard",
      "Pointer",
      "Crosshair",
      "Text",
      "Not allowed",
      "Wait",
      "Help",
      "Move"
    ],
    "Indexes": [
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.ProportionType": {
    "Values": [
      "No",
      "Width",
      "Height",
      "Min",
      "Max"
    ],
    "DisplayValues": [
      "No",
      "Width",
      "Height",
      "Min",
      "Max"
    ],
    "Indexes": [
      0,
      1,
      2,
      3,
      4
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.RowStyle": {
    "Fields": {
      "RowHeight": "STRING",
      "BorderThickness": "LREAL",
      "BorderColor": "HMI.SolidColorType",
      "BackgroundColor": "HMI.GradientColorType",
      "BackgroundColorEven": "HMI.GradientColorType",
      "BackgroundColorFilter": "HMI.GradientColorType",
      "FontName": "STRING",
      "FontSize": "BYTE",
      "TextColor": "HMI.SolidColorType",
      "TextColorFilter": "HMI.SolidColorType",
      "FontItalic": "BOOL",
      "FontBold": "BOOL",
      "FontUnderlined": "BOOL"
    },
    "DataType": "StructureType"
  },
  "HMI.SizeToContentType": {
    "Values": [
      "RealSize",
      "SetSize",
      "Crop",
      "Scroll"
    ],
    "DisplayValues": [
      "RealSize",
      "SetSize",
      "Crop",
      "Scroll"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.SizeType": {
    "Values": [
      "Pixel",
      "Relative"
    ],
    "DisplayValues": [
      "Pixel",
      "Relative"
    ],
    "Indexes": [
      0,
      1
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.SolidColorType": {
    "DataType": "ElementaryType"
  },
  "HMI.TileType": {
    "Values": [
      "No",
      "Tile",
      "Fill",
      "Center"
    ],
    "DisplayValues": [
      "No",
      "Tile",
      "Fill",
      "Center"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.VerticalAlignType": {
    "Values": [
      "Top",
      "Center",
      "Bottom"
    ],
    "DisplayValues": [
      "Top",
      "Center",
      "Bottom"
    ],
    "Indexes": [
      0,
      1,
      2
    ],
    "DataType": "EnumeratedType"
  },
  "LREAL": {
    "DataType": "ElementaryType"
  },
  "STRING": {
    "DataType": "ElementaryType"
  }
}
}
}