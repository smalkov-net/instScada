'use strict';
 export class Permissions { 
 static get globalPermissions () { 
 return {
  "CallProgram": {
    "displayName": "Call program",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "Control": {
    "displayName": "Control",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "DataTableEdit": {
    "displayName": "Edit table cells",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "DataTableFilter": {
    "displayName": "Use filters in table",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "DirectoryAdd": {
    "displayName": "Add data manager record",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "DirectoryDelete": {
    "displayName": "Delete data manager record",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "DirectoryEdit": {
    "displayName": "Edit data manager record",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "DirectoryFilter": {
    "displayName": "Use filters in data manager",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "IntervalsSettings": {
    "displayName": "Settings intervals",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "JournalAck": {
    "displayName": "Acknowledge alarm",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "JournalGroupAck": {
    "displayName": "Acknowledge group of alarms",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "JournalPrint": {
    "displayName": "Print messages",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "JournalSave": {
    "displayName": "Export messages",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "JournalUseFilters": {
    "displayName": "Use filters in log",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "Login": {
    "displayName": "Login",
    "requirePassword": false,
    "rights": {
      "_All": 9
    }
  },
  "OpenWindow": {
    "displayName": "Open window",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "PenGroupsCreate": {
    "displayName": "Create pen groups",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "ReadUsers": {
    "displayName": "Read users",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "ReadValue": {
    "displayName": "Read value",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "StandardIntervalsSelect": {
    "displayName": "Select standard intervals",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "TrendAddPens": {
    "displayName": "Manage pen list",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "TrendChangePens": {
    "displayName": "Manage pen settings",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "TrendPrint": {
    "displayName": "Print graph",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "TrendSave": {
    "displayName": "Export graph",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "WriteValue": {
    "displayName": "Write value",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  }
} 
 }
 static get objectsPermissions () { 
 return {
  "58003": {
    "parentId": 87
  }
} 
 }
 static get logActionTry () { 
 return {
  "_All": false
} 
 }
}